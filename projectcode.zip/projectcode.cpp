//provides basic input and output services for C++ programs
#include <iostream>
// predefines a set or operations for handling files related to input and output
#include<fstream>
//has several common functions for dealing with strings stored in arrays of characters
#include<string.h>
//provides access to the POSIX operating system API
#include <unistd.h>
// includes functions involving memory allocation, process control, conversions and others
#include <stdlib.h>
//used to operate on strings
#include<sstream>
//is used to related "console/screen" programs
#include<conio.h>

using namespace std;

/*The purpose of the function is to present
us a loading screen while the menu is
being presented*/
void loading2()
{
    cout<<"\t\t\t\tPlease wait while loading........."<<endl;
    char a=177,b=219;

    cout<<"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

    for(int k=0;k<=15;k++)
    {
        cout<<a;
    }
    cout<<"\r";
    cout<<"\t\t\t";

    for(int l=0;l<=15;l++)
    {
       cout<<b;
       for(int j=0;j<=1e7;j++)
    {

    }

    }

    system("cls");

}

/*An abstract base class is created
for inheritance purposes to link
    multiple classes to a same file
    and create a multi level
    inheritance system.*/
class super //abstract class
{
public:
  virtual void fun () = 0; //pure virtual function
  virtual void getinformation ()
  {
  }

};

/*Derived class that is storing all the
basic information regarding the customer or
the employee*/

class information:public super
{
protected:

  string fname, mname, lname, mno;
  int dd, mm, yy;
  int pin;

public:
  int pindiff;

  /*Default constructor initializing
  all the data members to null for whenever on object
  is being created*/

    information ()
  {
    mno = "null";
    fname = "null";
    mname = "null";
    lname = "null";
    dd = 0;
    mm = 0;
    yy = 0;
    pin = 0;
  }
  virtual void fun ()
  {
  }

  /*Member function of the information class
  which provides user with facility to enter
  details regarding themselves*/

  void getinformation ()
  {
    int m, count = 0;
    cout << endl << "Enter your name: ";
    cin >> fname;

    while (count == 0)
      {
//checks whether the user has a middle name or not
try
{
 cout << endl << "do you have a middle name: " << endl <<
   "1)yes \n2)no";
   cout<<endl;
   cin >> m;
   if (m > 2 || m < 1)
   {
        throw m;
   }

 if (m == 1)
   {
     cout << endl << "enter you middle name: ";
     cin >> mname;
   }
 else
   {
     mname = "\t";
   }
 cout << endl << "enter your Lastname:";
 cin >> lname;
 count = 1;
}


catch (int d)
{
 cout << endl << "THE CHOICE CAN BE 1 OR 2 ONLY";

}
      }
    count = 0;
    while (count == 0)
      {
try
{
 cout << endl << "enter date of birth:"<<endl;
 cout<<"Enter in DD/MM/YYYY format"<<endl;
 cin >> dd;
 cin >> mm;
 cin >> yy;
 cout<<dd<<" / "<<mm<<" / "<<yy;
 if (dd > 31 || dd < 1 || mm > 12 || mm < 1 || yy > 2010
     || yy < 1900)
   {
     throw 'c';
   }
 count = 1;
}
catch (char ch)
{
 cout << endl << "ENTER VALID D.0.B";
}
      }
    count = 0;
    while (count == 0)
      {
try
{
 cout << endl << "enter last 2 digit of your pin: ";
 cin >> pin;

 if (pin < 0 || pin > 100)
   {
     throw 'c';
   }
 count = 1;
}
catch (char ch)
{
 cout << endl << "ENTER VALID PIN BETWEEN 0 TO 100: ";
}
      }
    if (pin > 50)
      {
pindiff = pin - 50;
      }
    else
      {
pindiff = 50 - pin;
      }
  }
};

/*Derived class from class information
which has main purpose of presenting the menu
and redirect user to different choices and provide
variety of dishes */

class order:public information
{
protected:
  int bq, pq, dq, bp, pp, dp,ch;
public:

    /*The menu function allows user to
     choose from different cuisine options
      and discover food as well as
      multiple offers in each options given
      to make it more interesting.*/

  void menu ()
  {
    cout<<endl;
    cout<<"Enter choice:";
    cout<<endl;
    cout<<"(1) Continental";
    cout<<endl;
    cout<<"(2) Chinese";
    cout<<endl;
    cout<<"(3) Indian";
    cout<<endl;
    cout<<"(4) Sea Food";
    cout<<endl;
    cin>>ch;
    cout<<endl;
    switch(ch)
    {
    case 1:

        cout << endl << "\t\t\t\t TODAYS CONTINENTAL MENU IS" << endl;
                cout << "_";
        cout << endl << "|1 burger  | @just 75 |";
        cout << endl << "|2 pizza   | @just 100|";
        cout << endl << "|3 deal    | @just 200|";
        cout << endl << "|||";
        cout << endl << "todays deal is 1 pizaa + 1 burger + 1 coke(500ml)";
        break;

    case 2:

        cout << endl << "\t\t\t\t TODAYS CHINESE MENU IS" << endl;
                cout << "__";
        cout << endl << "|1 noodles        | @just 75 |";
        cout << endl << "|2 spring rolls   | @just 100|";
        cout << endl << "|3 deal           | @just 200|";
        cout << endl << "|_||";
        cout << endl << "todays deal is 1 noodles + 1 spring roll + 1 coke(500ml)";
        break;

    case 3:

        cout << endl << "\t\t\t\t TODAYS INDIAN MENU IS" << endl;
                cout << "__";
        cout << endl << "|1 chole bhature  | @just 75 |";
        cout << endl << "|2 paw bhaji      | @just 100|";
        cout << endl << "|3 thali          | @just 200|";
        cout << endl << "|_||";
        cout << endl << "todays deal is special thali + 1 gulab jamun + 1 lassi(500ml)";
        break;

    case 4:

        cout << endl << "\t\t\t\t TODAYS SEA FOOD MENU IS" << endl;
                cout << "__";
        cout << endl << "|1 crab         | @just 75 |";
        cout << endl << "|2 fish tikka   | @just 100|";
        cout << endl << "|3 deal         | @just 200|";
        cout << endl << "|_||";
        cout << endl << "todays deal is 1 fish tikka + 1 crab + 1 coke(500ml)";
        break;
        default:
        cout<<endl;
        cout<<"MORE MENU COMING SOON:)";
        break;
    }
  }
  void placeorder ()
  {
    int co = 0;
    while (co == 0)
      {
try
{
 cout << endl << "enter quantity for serial no 1: ";
 cin >> bq;
 if (bq < 0 || bq > 5)
   throw 1;
 bp = bq * 75;
 cout << endl << "enter quantity for serial no 2: ";
 cin >> pq;
 if (pq < 0 || pq > 5)
   throw 1;
 pp = pq * 100;
 cout << endl << "enter quantity for serial no 3: ";
 cin >> dq;
 if (dq < 0 || dq > 5)
   throw 1;
 if (bq + pq + dq == 0)
   throw 'c';
 dp = dq * 200;


 co = 1;
}
catch (int d)
{
 cout << endl <<
   "ENTER VALID ORDER QUANTITY  from 0(none) to 5(max)";
}
catch (char d)
{
 cout << endl << "YOU MUST ORDER SOMETHING";
}
      }

  }

};

/*After the order is decided from the class order,
derived class bill is initiated which calculates
the billing amount, taking in account other
factors such as taxes, delivery cost, mode of
payment etc.*/

class bill:public order
{
protected:

  float total, ordercost, delcost, tax;
  int deltime;
  int paymentchoice;

public:

  void makebill ()
  {
    if (pindiff == 0)
      {
delcost = 50;
deltime = 30 + (bq + pq + dq);
      }
    else if (pindiff > 0 && pindiff <= 10)
      {
delcost = 50 + pindiff;
deltime = 33 + 2 * (bq + pq + dq);
      }
    else if (pindiff > 10 && pindiff <= 20)
      {
delcost = 60 + 0.5 * pindiff;
deltime = 38 + 3 * (bq + pq + dq);
      }
    else if (pindiff > 30 && pindiff <= 40)
      {
delcost = 70 + 0.3 * pindiff;
deltime = 40 + 2 * (bq + pq + dq);
      }
    else if (pindiff > 40 && pindiff <= 50)
      {
delcost = 82 + 0.1 * pindiff;
deltime = 45 + (bq + pq + dq);
      }
    ordercost = dp + pp + bp;
    tax = 0.28 * (ordercost + delcost);
    total = ordercost + delcost + tax;
    cout<<endl;
    cout<<"YOUR TOTAL IS"<<total;
    int cp;
    int i;
    int ct=1;
    int qw=0;
    char cpp1[6]="IPL50";

    char cpp[6];
  cout<<endl;
  cout<<"Do you have a coupon code ";
  cout<<endl;
  cout<<"1.Yes";
  cout<<endl;
  cout<<"2.No";
  cout<<endl;
  cin>>cp;
  if(cp==1)
  {
      while(qw==0)
      {
      cout<<"Enter the coupon : ";
      cin>>cpp;
      for(i=0;i<5;i++)
      {
          if(strcmp(cpp,cpp1)==0)
          {
              ct=0;
          }

      }
      if(ct==0)
      {
          cout<<"Yayyyy!!! YOU GOT 50% DISCOUNT";
          total=total-0.5*total;
          cout<<endl;
          cout<<"Your new total is : "<<total;
          qw=1;
          cout<<endl;
      }
      else if(ct==1)
      {
        int k;
        cout<<"Either wrong coupon or coupon has expired";
        cout<<endl;
        cout<<"Do you want to try again?";
        cout<<endl;
        cout<<"1.yes";
        cout<<endl;
        cout<<"2.No";
        cout<<endl;
        cin>>k;
        if(k==1)
        {
            cout<<"\t\t\t\tPlease wait while loading........."<<endl;
    char a=177,b=219;
    cout<<"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
    for(int k=0;k<=15;k++)
    {
        cout<<a;
    }
    cout<<"\r";
    cout<<"\t\t\t";
    for(int l=0;l<=15;l++)
    {
       cout<<b;
       for(int j=0;j<=1e8;j++)
    {

    }

    }

    system("cls");
    getch();
        }
        else if(k==2)
        {
            qw=1;
        }
      }

      }
  }

  }
  void showbill ()
  {
    int co = 0, c;
    while (co == 0)
      {
try
{
 cout << endl << "Your total bill including delivery and tax is  " <<
   total;
   cout<<endl;

 cout << "Would you like a breakdown of the bill? " << endl <<
   "1) yes 2)no\n";
 cin >> c;
 if (c == 1)
   {
     cout << "__";
     cout << endl << "|delivery  | " << (int)delcost << "     |";
     cout << endl << "|order     | " << (int)ordercost << "   |";
     cout << endl << "|G.S.T     | " << (int)tax << "    |";
     cout << endl << "|||";
   }
 if (c < 1 || c > 2)
   throw 1;
 co = 1;
}
catch (int d)
{
 cout << "Enter CHOICE BETWEEN 1 &2" << endl;
}
      }
    co = 0;
    while (co == 0)
      {
try{
 cout << "\n\nHow would you like to pay" << endl << "1)online"<<endl<<"2)C.O.D"<<endl;
 cin >> paymentchoice;
 if(paymentchoice==1)
 {
     int po;
     cout<<"AVAILABLE PAYMENT OPTIONS:";
     cout<<endl;
     cout<<"1.UPI";
     cout<<endl;
     cout<<"2.Paytm wallet";
     cout<<endl;
     cout<<"3.NET BANKING";
     cout<<endl;
     cin>>po;
     switch(po)
     {
     case 1:
         cout<<endl;
         cout<<"Pay to UPI ID:XXXXXXXXXX@sbi.bank,in";
         break;
     case 2:
         cout<<endl;
         cout<<"Pay to Paytm Number:XXXXX-XXX01";
         break;
     case 3:
         cout<<endl;
         cout<<"Pay to account number:XXXXXXX@#$";
         cout<<endl;
         cout<<"IFSC CODE:sbiXX01:";
         cout<<endl;
         break;
     default:
        cout<<"enter valid mode";
        break;
     }
     cout<<"\t\t\t\tPlease wait while we recieve your order........."<<endl;
    char a=177,b=219;
    cout<<"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
    for(int k=0;k<=15;k++)
    {
        cout<<a;
    }
    cout<<"\r";
    cout<<"\t\t\t";
    for(int l=0;l<=15;l++)
    {
       cout<<b;
       for(int j=0;j<=1e8;j++)
    {

    }

    }

     cout<<endl;
     cout<<"Payment has been received";
     cout<<endl;
 }
 if (paymentchoice < 1 || paymentchoice > 2)//payment choice??
   throw 'c';
 cout << "YOUR Order will be delivered in " << deltime << "mins";
 co = 1;
}
catch (char d)
{
 cout << "Enter CHOICE BETWEEN 1 &2" << endl;
}
      }
  }
};

/*Creates a derived class from class bill
which creates a file to save the order data and bill in
data format file which helps to keep
a soft copy record of orders.*/

class file:public bill
{
public:

    int delid;
    static int co;

  void makefile ()
  {
    ofstream fo;
      fo.open ("bill.txt", ios::out | ios::binary);
      fo << "Name        = " << fname << mname << lname << endl;
      fo << "D.0.B       = " << dd << " . " << " . " << mm << " . " << yy <<
      endl;
      fo << "Adress(pin) = " << pin <<endl<<endl << endl;
      fo << "\t\t\t\t~Your order~" << endl << endl;
      switch(ch)
    {
    case 1:
        fo << endl << "\t\t\t\t YOUR CONTINENTAL ORDER IS" << endl;
                fo << "_";
      fo << endl << "|  burger  |  "<< bq<< "  |";
      fo << endl << "|  pizza   |  "<< pq<< "  |";
      fo << endl << "|  deal    |  "<< dq<< "  |";
      fo << endl << "|||" << endl << endl;
        break;
    case 2:
        fo << endl << "\t\t\t\t YOUR CHINESE ORDER IS" << endl;
                fo << "__";
      fo << endl << "|  noodles       |  "<< bq<< "  |";
      fo << endl << "|  spring rolls  |  "<< pq<< "  |";
      fo << endl << "|  deal          |  "<< dq<< "  |";
      fo << endl << "|__||" << endl << endl;
        break;
    case 3:
        fo << endl << "\t\t\t\t YOUR INDIAN ORDER IS" << endl;
                fo << "__";
      fo << endl << "|  chole bhature |  "<< bq<< "  |";
      fo << endl << "|  pav bhaji     |  "<< pq<< "  |";
      fo << endl << "|  thali         |  "<< dq<< "  |";
      fo << endl << "|__||" << endl << endl;
        break;
    case 4:
fo << endl << "\t\t\t\t YOUR SEA FOOD ORDER IS" << endl;
              fo << "__";
      fo << endl << "|  crab        |  "<< bq<< "  |";
      fo << endl << "|  fish tikka  |  "<< pq<< "  |";
      fo << endl << "|  deal        |  "<< dq<< "  |";
      fo << endl << "|__||" << endl << endl;
        break;
        default:
        cout<<endl;
        cout<<"MORE MENU COMING SOON:)";
        break;
    }

      fo << "\t\t\t\t~Your bill~" << endl << endl;
      fo << "__";
     fo<< endl << "|delivery  | " << (int)delcost << "     |";
     fo<< endl << "|order     | " << (int)ordercost << "   |";
     fo << endl << "|G.S.T     | " << (int)tax << "    |";
     fo << endl << "|||";

      fo << endl << "Your total cost is " << total;
    if (paymentchoice == 1)
      {
          fo << endl << "You have chosen online payment";

      }
    else if (paymentchoice == 2)
      {
          fo << endl << "You have choosen C.O.D";
      }

      fo << endl << "Your order will be with you in " << deltime << " mins";
      delid=1000+co;
      co++;
      fo<<endl<<"Your delivery agent "<<delid;
    fo.close();

  }
};
int file::co=1;

/*Extra class derived from class Information
in case if the customers want to
file a complaint regarding the system.*/

class complaint:public information
{ protected:
    static int co;
    int delid2;

public:
    void getcomplaint()
    {
        int comp;
        cout<<endl<<"Enter your complaint: ";
        cout<<endl;
        cout<<"1.Food was cold";
        cout<<endl;
        cout<<"2.Delivery was late";
        cout<<endl;
        cout<<"3.Food quality was not adequate";
        cout<<endl;
        cout<<"4 Customer Service is poor";
        cout<<endl;
        cin>>comp;
        cout<<endl<<"Enter the delivery id mentioned in your file:";
        cin>>delid2;
        cout<<endl;
        cout<<"THANKS FOR HELPING US IMPROVE OUR SERVICE";

        if(co==1)
        {
            cout<<endl<<"AS its your first complaint you will be given full refund";
        }
        else if(co==2)
        {
            cout<<endl<<"AS its your second complaint you will be given half refund";
        }
        else if(co>2)
        {
            cout<<endl<<"sorry! we regret to inform, you that We cant give you a refund";
        }
      co++;

    }



};
int complaint::co=1;



void loading()
{
    int numberOfDots;
    double timeInterval;
    cout <<endl<< "LOADING ";
    for ( numberOfDots = 0; numberOfDots <= 15; numberOfDots++ )
    {
        cout << ".";
        for ( timeInterval = 0; timeInterval <= 10000000; timeInterval++);

        /*increase the number of zeroes in timeInterval's end value
        to make the loading dots last longer or reduce them to make them
        run away.*/

    }
}

/*Class with data members related to
employees and member functions to get data
regarding employees. */

class Employee
{  protected:
    static int c;
    int n,emp_id;
    string emp_name;
    string emp_mno;
    public:
    void getempdata()
    {
        emp_id=1000+c;

           cout<<"Enter name:";
           cin>>emp_name;
           cout<<endl;
           cout<<endl;
           cout<<"1 enter mobile no:";
           cin>>emp_mno;
           cout<<endl;

cout<<"Your Employee id is: "<<emp_id;
cout<<endl;
           c++;


    }
};
int Employee :: c=1;

/*class to allow user to give reviews
regarding the system and its facilities.*/

    class reviews
    {
        int r;
        string comm;
        public:
        void getreviews()
        {
        cout<<endl;
        cout<<"NOTHING BRINGS PEOPLE TOGETHER LIKE FOOD*";
        cout<<endl;
        cout<<"twice and thrice over, as they say, good it is repeat and review, what you say??";
        cout<<endl;
        cout<<"please provide us the review everytime you order as it will help us grow";
        cout<<endl;
        cout<<"1.Excellent";
        cout<<endl;
        cout<<"2.Good";
        cout<<endl;
        cout<<"3.Poor";
        cout<<endl;
        cin>>r;
        switch(r)
        {
        case 1:

            cout<<"thank you for your review, we are very happy you like our food";
            break;

        case 2:

            cout<<"thank you for your review, do comment how can we improve more";
            cout<<endl;
            cin>>comm;
            break;

        case 3:

            cout<<"thank you for your review, we are sorry you are disappointed, please let us know what you don't like by commenting:";
            cout<<endl;
            cin>>comm;
            break;

        default:

            cout<<"please review properly";
            break;

        }
    }
};

/*Class load is being derived from class file and
class reviews and is purpose is to
provide a loading screen and the display
for the ordering system at the beginning of the
    output.*/

class load:public file,public reviews
{
public:

    load()
    {
        cout<<"\t\t\t\tPlease wait while loading........."<<endl;
    char a=177,b=219;
    cout<<"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
    for(int k=0;k<=15;k++)
    {
        cout<<a;
    }
    cout<<"\r";
    cout<<"\t\t\t";
    for(int l=0;l<=15;l++)
    {
       cout<<b;
       for(int j=0;j<=1e8;j++)
    {

    }

    }
    system("cls");


    cout<<endl<<"FFFFFF     OO        OO      DDDDDD"  ;
    cout<<endl<<"FF       OO  OO    OO  OO    DD    D" ;
    cout<<endl<<"FFFFFF  OOO  OOO  OOO  OOO   DD     D";
    cout<<endl<<"FF       OO  OO    OO  OO    DD    D" ;
    cout<<endl<<"FF         OO        OO      DDDDDD"  ;


    cout<<endl;
    cout<<endl;


    cout<<endl<<"   OO     RRRRR   DDDDDD    EEEEE  RRRRR   I  N       N   GGGG     ";
    cout<<endl<<" OO  OO   R    R  DD    D   E      R    R  I  N N     N  G         ";
    cout<<endl<<"OOO  OOO  RRRRR   DD     D  EEE    RRRRR   I  N   N   N G   GGG    ";
    cout<<endl<<" OO  OO   R  R    DD    D   E      R  R    I  N     N N  G    G    ";
    cout<<endl<<"   OO     R    R  DDDDDD    EEEEE  R   R   I  N       N   GGGGG    ";


    cout<<endl;
    cout<<endl;


    cout<<endl<<"   SSS   Y      Y   SSS    TTTTT  EEEEE   MM         MM           ";
    cout<<endl<<"  S        Y  Y    S         T    E       M M       M M           ";
    cout<<endl<<"   SSS      YY      SSS      T    EEE     M   M    M  M           ";
    cout<<endl<<"      S     YY         S     T    E       M    M M    M           ";
    cout<<endl<<"  SSSS      YY     SSSS      T    EEEEE   M     M     M           ";


    cout<<endl;
    cout<<endl;

    }
};
int main ()
{ int counter =0;
int jkkl;

while(counter==0)
{

complaint ptr;
load o1;
Employee o2;

int l;
int k;
int j;

    cout<<endl;
    cout<<endl;
    cout<<endl;
    cout<<endl<<"ENTER 1 FOR EMPLOYEE REGISTRATION 2 FOR CUSTOMER "<<endl;
    cin>>k;
if(k==2)
{
cout<<endl<<"ENTER 1 FOR PLACING ORDER 2 FOR FILLING A COMPLAINT "<<endl;
cin>>j;
if(j==1)
  {
  int cow=0;
  while(cow==0)
  {
      int jk;

  loading2();
  o1.getinformation();
  loading();
  o1.menu();
  loading();
  o1.placeorder();
  loading();
  o1.makebill();
  loading();
  o1.showbill();
  o1.getreviews();
  o1.makefile();

  cout<<endl;
  cout<<"WOULD YOU LIKE TO PLACE ANOTHER ORDER"<<endl<<"1)yes "<<endl<<"2)no";
  cout<<endl;
  cin>>jk;
  if(jk==2)
  {
      cow=1;
  }

  }
  }
if(j==2)
{int cow=0;
  while(cow==0)
  {int jk;
  loading2();
  loading();
  ptr.getcomplaint();
  loading();
  cout<<endl;
  cout<<"WOULD YOU LIKE TO PLACE ANOTHER COMPLAINT "<<endl<<"1)yes "<<endl<<"2)no";
  cout<<endl;
  cin>>jk;
  if(jk==2)
  {
      cow=1;
  }
  }

}



}
else if(k==1)
{
    int meow=0;
  while(meow==0)
  {
  o2.getempdata();

  int jkk;
  cout<<endl;
  cout<<"WOULD YOU LIKE TO REGISTER AGAIN "<<endl<<"1)yes "<<endl<<"2)no";
  cout<<endl;
  cin>>jkk;
  if(jkk==2)
  {
      meow=1;
  }
}

}
int pqrs=0;
while(pqrs==0)
{
try{
cout<<"WOULD YOU LIKE TO REPEAT THE PROCESS (run the code again) "<<endl<<"1)yes "<<endl<<"2)no";
  cout<<endl;
  cin>>jkkl;
  if(jkkl==2)
  {
      counter=1;
  }
  else if(jkkl>2||jkkl<1)
  {
  throw 'c';

  }
  pqrs=1;
  }
  catch(char c)
  {
      cout<<endl<<"ENTER VALID CHOICE 1 OR 2";
      cout<<endl;
  }
}
}

cout<<endl;
cout<<"THANK YOU FOR VISITING, PLEASE DO VISIT AGAIN ;)";
cout<<endl;
return 0;

}
